package com.example.demo.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.interfaceService.IProductoService;

import com.example.demo.interfaces.IProducto;
import com.example.demo.modelo.producto;

@Service
public class ProductoService implements IProductoService{
	
	@Autowired
	private IProducto data;
	 
	@Override
	public List<producto> listar() {
		return (List<producto>)data.findAll();
	}

	@Override
	public Optional<producto> listarId(int id) {
		// TODO Auto-generated method stub
		return data.findById(id);
	}

	@Override
	public int save(producto c) {
		producto result = data.save(c);
		return result.getId();
	}
	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		data.deleteById(id);
	}
	

}
