package com.example.demo.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Personal")
public class personal {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codPersonal;
	private int celular;
	private String nombre, apellido;
	
	public personal() {
		// TODO Auto-generated constructor stub
	}

	public int getCodPersonal() {
		return codPersonal;
	}

	public void setCodPersonal(int codPersonal) {
		this.codPersonal = codPersonal;
	}

	public int getCelular() {
		return celular;
	}

	public void setCelular(int celular) {
		this.celular = celular;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	

}
