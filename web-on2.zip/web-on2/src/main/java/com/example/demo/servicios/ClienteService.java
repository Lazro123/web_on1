package com.example.demo.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.interfaceService.IclienteService;
import com.example.demo.interfaces.ICliente;
import com.example.demo.modelo.cliente;

@Service
public class ClienteService implements IclienteService{
	
	@Autowired
	private ICliente data;
	 
	@Override
	public List<cliente> listar() {
		return (List<cliente>)data.findAll();
	}

	@Override
	public Optional<cliente> listarId(int id) {
		// TODO Auto-generated method stub
		return data.findById(id);
	}

	@Override
	public int save(cliente c) {
		cliente result = data.save(c);
		return result.getId();
	}
	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		data.deleteById(id);
	}
	

}
