package com.example.demo.interfaceService;

import java.util.List;
import java.util.Optional;

import com.example.demo.modelo.producto;

public interface IProductoService {
	public List<producto>listar();
	public Optional<producto>listarId(int id);
	public int save(producto c);
	public void delete(int id);
}
