package com.example.demo.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Productos")
public class pedidos {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Cliente_DNI;
	private int codPedido;
	private int Producto_codProd;
	private int Personal_codPersonal;
	
	public pedidos() {
		//TODO Auto-generated constructor stub		
	}

	public int getCliente_DNI() {
		return Cliente_DNI;
	}

	public void setCliente_DNI(int cliente_DNI) {
		Cliente_DNI = cliente_DNI;
	}

	public int getCodPedido() {
		return codPedido;
	}

	public void setCodPedido(int codPedido) {
		this.codPedido = codPedido;
	}

	public int getProducto_codProd() {
		return Producto_codProd;
	}

	public void setProducto_codProd(int producto_codProd) {
		Producto_codProd = producto_codProd;
	}

	public int getPersonal_codPersonal() {
		return Personal_codPersonal;
	}

	public void setPersonal_codPersonal(int personal_codPersonal) {
		Personal_codPersonal = personal_codPersonal;
	}
	

}
