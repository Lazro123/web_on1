package com.example.demo.interfaceService;

import java.util.List;
import java.util.Optional;

import com.example.demo.modelo.cliente;

public interface IclienteService {
	public List<cliente>listar();
	public Optional<cliente>listarId(int DNI);
	public int save(cliente c);
	public void delete(int DNI);
}
